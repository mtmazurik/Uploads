﻿CREATE USER [usrCA] FOR LOGIN [usrCA];





