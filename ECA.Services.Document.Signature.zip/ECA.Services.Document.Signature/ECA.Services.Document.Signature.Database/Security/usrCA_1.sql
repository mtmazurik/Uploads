﻿CREATE LOGIN [usrCA]
    WITH PASSWORD = N'?Gt|vzxm=zz}uoP|rkvn=#nlmsFT7_&#$!~<qkke|jx|xi|u', SID = 0xAB224522F184E94E8DA8AE0C18228428, DEFAULT_LANGUAGE = [us_english], CHECK_POLICY = OFF;

