﻿CREATE TABLE [dbo].[Document] (
    [EnvelopeId]     UNIQUEIDENTIFIER NOT NULL,
    [Name]           NVARCHAR (50)    NOT NULL,
    [Type]           NVARCHAR (50)    NOT NULL,
    [Uri]            NVARCHAR (MAX)   NOT NULL,
    [Pages]          NVARCHAR (50)    NOT NULL,
    [DocumentBytes]  VARBINARY (MAX)   NOT NULL
);

