﻿Testing with these data points

baseUrl:		https://demo.docusign.net/restapi
username:		slewarne@epiqsystems.com
password:		P@ssword1
clientId:		071cb13c-874c-47a3-9509-24322de20a34
templateId:		00e571b0-a6e8-4709-aaad-3b50f82bdcbb					//  'Testing Template' template
accountId:		3474324
documentId:		87929621

templateId:		4a39ce48-cdcd-466d-9c68-4b7c8529a211					//  'Many Fields' template


Second Account (developer) for DocuSign (admin permission set)
baseUrl:		https://demo.docusign.net/restapi
username:		mmazurik@epiqsystems.com
password:		P@ssword1
accountId:		4823252
		
subordinate to Second Account (sender permission set)

baseUrl:		https://demo.docusign.net/restapi
username:		mmazurik@epiqglobal.com
password:		P@ssword1