﻿using ECA.Services.Document.Signature.Config;
using ECA.Services.Document.Signature.DAL;
using DataModels = ECA.Services.Document.Signature.DAL.Models;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ECA.Services.Document.Signature.DocuSign.Builders;
using ECA.Services.Document.Signature.Models;
using System.Threading;

namespace ECA.Services.Document.Signature.Tasks
{
    public class DocuSignStatusUpdater : IDocuSignStatusUpdater
    {
        private Logger _logger;
        private IJsonConfiguration _config;
        private IRepository _repo;
        private IStatusRequestBuilder _statusBuilder;
        private IDocumentRequestBuilder _documentRequestBuilder;

        public DocuSignStatusUpdater(IJsonConfiguration config, IRepository repo, IStatusRequestBuilder statusBuilder, IDocumentRequestBuilder documentRequestBuilder)                 //ctor
        {
            _logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
            _config = config;
            _repo = repo;
            _statusBuilder = statusBuilder;
            _documentRequestBuilder = documentRequestBuilder;
        }

        public async Task Update()
        {
            try
            {
                await Task.Run(() => CheckSignatureStatuses());
            }
            catch (Exception exc)
            {
                _logger.Error(exc, "DocuSignStatusUpdater.Update() thread error.");
            }
        }

        private void CheckSignatureStatuses()
        {
            List<DataModels.Signature> signatures;
            // read all signatures from DB
            try
            {
                signatures = _repo.ReadAllSignatures();
            }
            catch(Exception exc)
            {
                _logger.Error(exc, "Error reading signatures table.");
                throw exc;
            }
            foreach( DataModels.Signature signature in signatures)
            {
                try
                {
                    if (signature.Status != "completed" &
                        signature.Status != "declined" &
                        signature.Status != "voided" &
                        signature.Status != "expired")
                    {

                        IResponse response;
                        string envelopeId = signature.EnvelopeId.ToString();
                        _statusBuilder.Build(envelopeId, signature.DocuSignUsername, signature.DocuSignPassword, out response);   // get current DocuSign status
                        string currentStatus = ((EnvelopeStatus)response.Data).Status;
                        _logger.Debug($"GetStatus() value: {currentStatus}, envelopeId: {envelopeId}");


                        if (!(string.Compare(currentStatus, signature.Status) == 0))   // if status is different
                        {
                            _logger.Debug($"Updating status:  from: {signature.Status} to: {currentStatus} EnvelopeId {envelopeId} ");
                            signature.Status = currentStatus;
                            _repo.UpdateSignature(signature);                          // save current status to database 
                            if((string.Compare(currentStatus,"completed")==0))        // if completed, grab the documents and throw in SigSvc db
                            { 
                                _documentRequestBuilder.Build(envelopeId, signature.DocuSignUsername, signature.DocuSignPassword, out response);
                            }
                        }
                        else
                        {
                            _logger.Debug("No update needed.");
                        }
                    }
                }
                catch(Exception exc)
                {
                    _logger.Error(exc, "Error in processing loop, foreach signature.");
                }
            }
        }
    }
}
