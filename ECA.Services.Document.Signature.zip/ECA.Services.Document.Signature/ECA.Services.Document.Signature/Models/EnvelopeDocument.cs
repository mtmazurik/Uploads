﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECA.Services.Document.Signature.Models
{
    public class EnvelopeDocument
    {
        public string DocumentId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Uri { get; set; }
        public string Order { get; set; }
        public string Pages { get; set; }
        public AvailableDocumentTypes[] AvailableDocumentTypes { get; set; }
        public string Display { get; set; }
        public string IncludeInDownload { get; set; }
        public string SignerMustAcknowledge { get; set; }

    }

    public class AvailableDocumentTypes
    {
        public string Type { get; set; }
        public string IsDefault { get; set; }
    }
}
