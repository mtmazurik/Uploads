﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Threading = System.Threading.Tasks.Task;
using ECA.Services.Document.Signature.Config;
using ECA.Services.Document.Signature.DocuSign.Exceptions;
using ECA.Services.Document.Signature.Models;
using DataModels = ECA.Services.Document.Signature.DAL.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;
using ECA.Services.Document.Signature.DAL;

namespace ECA.Services.Document.Signature.DocuSign.Builders
{
    public class DocumentRequestBuilder : IDocumentRequestBuilder
    {
        static private IRestApiWrapper _api;
        private IJsonConfiguration _config;
        private Logger _logger;
        private IRepository _repository;
        static byte[] _docBytes;
        public DocumentRequestBuilder(IRestApiWrapper wrapper, IJsonConfiguration config, IRepository repository)   // ctor
        {
            _api = wrapper;
            _config = config;
            _logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
            _repository = repository;
        }
        public bool Build(string envelopeId, string username, string password, out IResponse response)
        {
            Response returnResponse = new Response();

            // 1 - Account username/password to get ID
            string accountId = _api.GetAccountId(username, password);

            // 2 - /v2/accounts/{{accountId}}/envelopes/80cda4bf-a521-48f5-a5ee-bb966582591b/documents    Get All Documents for envelope id
            string uri = $"{_config.ApiUrl}/v2/accounts/{accountId}/envelopes/{envelopeId}/documents";
  
            JObject resultObject;
            HttpStatusCode status = _api.SendDocuSignRequest(HttpMethod.Get, uri, username, password, out resultObject);
            if (status != HttpStatusCode.OK)
            {
                string message = "Get Envelope status failed. Check envelopeId and Account header information and retry.";
                _logger.Error( $"Build() {message}");
                throw new SigSvcDocuSignAPICallFailure(message);
            }
            else
            {
                // 3 - Loop over returned documents making 2ndary call to  /v2/accounts/{{accountId}}/envelopes/80cda4bf-a521-48f5-a5ee-bb966582591b/documents  /certificate
                JArray jDocArray = resultObject["envelopeDocuments"].Value<JArray>();

                foreach ( JObject jDocument in jDocArray)
                {
                    EnvelopeDocument envelopeDocument = JsonConvert.DeserializeObject<EnvelopeDocument>(jDocument.ToString());                   
                    string fileUri =  $"{_config.ApiUrl}/V2/accounts/{accountId}" + envelopeDocument.Uri;
                    DownloadFileBytes(fileUri, username, password).ConfigureAwait(false);     // uses the URI to get the bytes                           
                    WriteToRepository(envelopeId, envelopeDocument, _docBytes);                    // saves the Document information into the database using the DAL layer's Document datamodel  with a key:   envelopeId
                }
            }
            response = returnResponse;
            return true;
        }
        public static async Task DownloadFileBytes(string uri,  string username, string password)
        {
            using (var client = new HttpClient())
            {
                HttpRequestMessage request = _api.FormatRequest(HttpMethod.Get, uri, username, password);
                using (HttpResponseMessage result = client.SendAsync(request).Result )
                { 
                    using (Stream contentStream = await result.Content.ReadAsStreamAsync())
                    {
                        using (var br = new BinaryReader(contentStream))
                        {
                            int length = (int)contentStream.Length;
                            _docBytes = new byte[0];
                            Array.Resize<byte>(ref _docBytes, length);
                            Array.Copy(br.ReadBytes((int)contentStream.Length), _docBytes, length);
                        }
                    }
                }
            }
        }
        private void WriteToRepository(string envelopeId, EnvelopeDocument document, byte[] documentBytes)
        {
            _repository.CreateDocument(new DataModels.Document        // save to database
            {
                EnvelopeId = Guid.Parse(envelopeId),
                Name = document.Name,
                Pages = document.Pages,
                Type = "PDF",
                Uri = document.Uri,
                DocumentBytes = documentBytes
            });
        }
    }
    public interface IDocumentRequestBuilder              // interface - really only used for injecting
    {
        bool Build(string envelopeId, string username, string password, out Models.IResponse response);
    }
}
