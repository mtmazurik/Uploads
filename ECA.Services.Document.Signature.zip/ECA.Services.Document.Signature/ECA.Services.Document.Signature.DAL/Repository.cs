﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace ECA.Services.Document.Signature.DAL
{
    public class Repository : IRepository
    {

        private string _connectionString;

        public Repository(string connectionString)
        {
            _connectionString = connectionString;
        }

        private RepositoryContext InitializeContext()
        {
            var builder = new DbContextOptionsBuilder<RepositoryContext>();
            builder.UseSqlServer(_connectionString);
            return new RepositoryContext(builder.Options);
        }
        public Models.Signature ReadSignature(int signatureId)
        {
            Models.Signature signature;

            RepositoryContext context = InitializeContext();
            signature = context.Signatures.Find(signatureId);
            context.Dispose();

            return signature;
        }
        public List<Models.Signature> ReadAllSignatures()
        {
            RepositoryContext context = InitializeContext();
            List<Models.Signature> signatures = new List<Models.Signature>(context.Signatures.FromSql("Select * from Signature"));
            context.Dispose();
            return signatures;
        }
        public void CreateSignature(Models.Signature newSignature)
        {
            RepositoryContext context = InitializeContext();
            newSignature.UTCDateTimeCreated = DateTime.UtcNow;
            context.Add(newSignature);
            context.SaveChanges();
            context.Dispose();
        }
        public void CreateDocument(Models.Document newDocument)
        {
            RepositoryContext context = InitializeContext();
            context.Add(newDocument);
            context.SaveChanges();
            context.Dispose();
        }
        public void UpdateSignature(Models.Signature updatedSignature)
        {
            RepositoryContext context = InitializeContext();
            var result = context.Signatures.Find(updatedSignature.SignatureId);
            if( result != null)
            {
                result.Status = updatedSignature.Status;
                result.UTCDateTimeLastUpdated = DateTime.UtcNow;
                context.SaveChanges();
            }
            context.Dispose();
        }

    }
    public class RepositoryContext : DbContext
    {

        public RepositoryContext(DbContextOptions<RepositoryContext> options = null) : base(options)
        {
        }
        public virtual DbSet<Models.Signature> Signatures { get; set; }

        public virtual DbSet<Models.Document> Document { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Models.Signature>()
                .HasKey(p => p.SignatureId)
                .HasName("Signature");

            builder.Entity<Models.Document>()
                .HasKey(p => p.EnvelopeId)
                .HasName("Document");
        }
    }

}
