﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using System.Linq;

namespace ECA.Services.Document.Signature.DAL.Models
{
    [Table("Document")]
    public partial class Document
    {
        public Guid EnvelopeId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Uri { get; set; }
        public string Pages { get; set; }
        public byte[] DocumentBytes { get; set; }
    }
}
